# Blinker Catálogo Interno

13 catálogos completos e 4 206 páginas. A coleção inclui Hotelaria, obtido na biblioteca oficial da Blinker, com 69 páginas e 20 entradas do índice original.

## Revisão documental

Foi removido o texto de tinta em spray atribuído ao cartão RAL 0455001. Nove tabelas foram separadas das aplicações/instruções. A unidade de fluxo luminoso 500 ml foi corrigida para 500 lm na referência 0842311036, conforme a tabela original.

87 transcrições foram conferidas com o PDF; isso não significa aprovação técnica integral. A correspondência de modelo e tamanho foi documentada em 592 referências Sparco usando modelo, família e intervalo no mesmo bloco do PDF. Não foram atribuídas características ou homologações a partir dessa correspondência.

As onze referências com divergências ou ambiguidades remanescentes têm aviso específico. O kit 04599328 tem conteúdo de 15 kg confirmado na página oficial; as proporções continuam por esclarecer. A página francesa da referência 0842311020 confirma 6500 K, mas as dimensões continuam pendentes.

Consultar revisao-fichas.html para filtrar por estado e catálogo, ver os textos e as tabelas e descarregar pendencias-documentais.csv. A lista conserva as referências como texto e indica a evidência ainda necessária.

Falta um PDF independente identificado como Indústria Alimentar II. Não foi duplicado o documento disponível de Indústria Alimentar. Não se presumiram preços, características, equivalências exatas ou certificações.

A tarifa de 11/11/2026, os 28 377 produtos, as quatro fichas piloto e a revisão anterior das equivalências mantêm-se.
