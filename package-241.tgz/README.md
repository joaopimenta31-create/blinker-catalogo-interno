# Consulta documental Blinker

A revisão das fichas permite pesquisar todas as 28.377 referências do inventário e consultar os respetivos estados e fontes.

Há quatro fichas piloto documentadas, 39 extrações automáticas de Químicos por validar, 18.272 fichas documentais parciais e 10.062 referências sem página associada nos quatro catálogos processados. A publicação desta consulta não transforma rascunhos em especificações aprovadas.

Usa os filtros por lote e estado. Abre a ficha de um produto para consultar as fontes disponíveis, ou a página original do catálogo. Os dados comerciais mantêm a tarifa de 11/11/2026. Uma página pode conter vários artigos ou variantes; não se atribuem automaticamente todas as características a cada referência.

As quatro fichas piloto incluem fotografias extraídas do PDF original. Nos restantes casos, a imagem disponível é a página do catálogo, não uma fotografia individual validada. Campos ausentes ou contraditórios ficam por confirmar.

Os 39 rascunhos e as páginas partilhadas exigem revisão da imagem, identificação exata da variante e validação das afirmações antes de uma eventual promoção a ficha técnica de produto. As referências sem página associada são uma lista de trabalho, não prova de ausência em toda a documentação Blinker.
