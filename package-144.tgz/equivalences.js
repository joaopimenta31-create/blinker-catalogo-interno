/* Equivalências: apenas registos documentados devem ser adicionados a este ficheiro. */
const EQUIVALENCES = [
  ['Würth', '0827 082 032', 'Espanha', 'https://www.wurth.es/pila-boton-3v-cr-2032-dl-2032'],
  ['Berner', '198891', 'Alemanha', 'https://shop.berner.eu/de-de/p/198624-lithium-knopfzellen-von-energizer-lithium-cr-serie.html?article_id=198891'],
  ['Förch', '3882 2032', 'Austrália', 'https://www.forch.com.au/3882-2032-coin-battery-cr-2032-3v']
].map(([brand, code, region, url]) => ({
  brand, code, blinkerCode: '0130502', name: 'Pilha de lítio CR2032',
  status: 'Equivalente no formato e tensão',
  application: 'Para comandos de automóvel e outros aparelhos que especificam CR2032 de 3 V.',
  differences: 'Capacidade, autonomia e embalagem por comparar. Referência do catálogo de ' + region + '. Disponibilidade em Portugal por confirmar.',
  checkedAt: '05/11/2026',
  sources: [{label:'Abrir produto '+brand+' · '+code, url}, {label:'Consultar ficha Blinker', url:'https://blinkergroup.com/pt-pt/pilhas-botao-litio/'}]
}));
const handCleaners = [
  ['Würth','08939055','Massa lava-mãos Tradicional · 4 L','Limpeza das mãos com abrasivo natural.','Aroma a limão. Aplicar nas mãos secas. Portugal.','https://eshop.wurth.pt/Categorias-de-Produto/Pasta-de-limpeza-tradicional-para-maos/31240502020229.cyid/3124.cgid/pt/PT/EUR/'],
  ['Würth','0893900059','Massa branca Plastic Free · 5 L','Limpeza com microesferas minerais.','Lavanda. Embalagem de 5 L. Portugal.','https://eshop.wurth.pt/Categorias-de-Produto/Pasta-de-limpeza-para-maos-livre-de-microplastico/31243007230495.cyid/3124.cgid/pt/PT/EUR/'],
  ['Berner','1000578','Fresh & Clean','Pasta para a limpeza diária das mãos na oficina.','Confirmar embalagem e adequação ao tipo de sujidade. Portugal.','https://shop.berner.eu/pt-pt/p/55067-pasta-lava-maos-fresh-clean-pasta.html?article_id=1000578'],
  ['Berner','362812','Lava mãos Pro Bio','Produto de limpeza das mãos.','Comparar embalagem e sistema de dosagem. Portugal.','https://shop.berner.eu/pt-pt/p/25731915-lava-maos-pro-bio.html?article_id=362812'],
  ['Förch','6180 9139','Derma Top E · 3 L','Limpeza das mãos em oficina.','Embalagem de 3 L. Catálogo australiano.','https://www.forch.com.au/6180-9139-derma-top-e-hand-cleaner-3l'],
  ['Förch','6180 9173','Derma Craft E · 3 L','Limpeza das mãos em oficina.','Embalagem de 3 L. Catálogo australiano.','https://www.forch.com.au/6180-9173-derma-craft-e-hand-clean-3lt'],
  ['Würth', '0893960004', 'Xtreme · 4 L', 'Para gordura, tintas e resíduos de poliuretano.', 'Aplica-se sobre as mãos secas. A Blinker indica mãos humedecidas. Ficha de Espanha.', 'https://www.wurth.es/pasta-lavamanos-xtreme-4l-1'],
  ['Berner', '424215', 'Pasta lava mãos II · 4 L', 'Para oficinas, incluindo óleos, gorduras, tintas e resinas.', 'Balde de 4 L com aroma cítrico. A Blinker tem aroma a lavanda. Ficha de Portugal.', 'https://shop.berner.eu/pt-pt/p/55868776-pasta-lava-maos-ii-balde.html?article_id=424215'],
  ['Förch', '6180 9034', 'Clean and Care · 10 L', 'Pasta com partículas de madeira para remover óleos e gorduras das mãos.', 'Embalagem de 10 L. A ficha norueguesa documenta óleos e gorduras; o uso para tintas ou poliuretanos fica por confirmar.', 'https://www.forch.pt/search/6180%209034']
];
for (const [brand, code, name, application, differences, url] of handCleaners) {
  EQUIVALENCES.push({blinkerCode:'04548210', brand, code, name, application, differences,
    status:'Alternativa por aplicação', checkedAt:'05/11/2026',
    sources:[{label:(code==='6180 9034'?'Pesquisar referência ':'Abrir produto ')+brand+' · '+code, url},
      {label:'Consultar ficha Blinker · 4 L', url:'https://blinkergroup.com/pt-pt/massa-lava-maos-plus/'}]});
}
const wurthCopper = 'https://www.wurth.es/media/catalog/productdownloads/0/3/03_05_0120.pdf';
const copperOptions = [
  ['04519','Würth','0893 800','CU 800 · spray 300 ml','Mesmo volume. Limite publicado de 800 °C, inferior aos 1 200 °C indicados pela Blinker.',wurthCopper],
  ['04519','Berner','147707','Spray de cobre · 400 ml','400 ml face a 300 ml. A ficha indica até 1 200 °C.','https://shop.berner.eu/pt-pt/p/14781-lubrificante-deslizante-de-cobre.html?article_id=147707'],
  ['04519','Förch','6510 5000','S425 · spray 300 ml','Mesmo volume. O limite do spray é 800 °C, inferior ao indicado pela Blinker.','https://www.forch.com.au/6510-5000-copper-spray-s425-300ml'],
  ['04520','Förch','6510 5001','S425 · tubo 100 g','Tubo de 100 g face à lata Blinker de 800 g. Catálogo australiano.','https://www.forch.com.au/6510-5001-copper-paste-s425-100gr-tube'],
  ['04520','Würth','0893 800 2','CU 800 · lata 1 kg','1 kg face a 800 g. Limite publicado de 800 °C.',wurthCopper],
  ['04520','Berner','399269','Pasta de cobre · 100 g','Embalagem de 100 g face à lata Blinker de 800 g.','https://shop.berner.eu/be-fr/p/14781-pate-spray-cuivre.html?article_id=399269'],
  ['04520','Förch','6510 5002','S425 · lata 1 kg','1 kg face a 800 g. Limite publicado da pasta de 1 100 °C.','https://www.forch.com.au/6510-5002-copper-paste-s425-1000g-%2810%29']
];
for (const [blinkerCode,brand,code,name,differences,url] of copperOptions) {
  EQUIVALENCES.push({blinkerCode,brand,code,name,differences,status:'Alternativa por aplicação',
    application:'Montagem de uniões metálicas com proteção contra gripagem. Confirmar materiais e temperatura para a aplicação.',
    checkedAt:'05/11/2026',sources:[{label:'Abrir ficha '+brand+' · '+code,url},{label:'Ficha Blinker',url:'https://blinkergroup.com/pt-pt/pasta-de-cobre/'}]});
}
const wurthTerms = [
  [/\b(?:maos?|mao)\b/, /\b(?:lava\w*|limp\w*|pasta|massa|sabao|sabonete)\b/, ['pasta de limpeza para mãos','massa lava-mãos','limpeza de mãos']],
  [/\bcobre\b/, /\b(?:massa|pasta|spray|lubrificante|antigripante)\b/, ['CU 800','pasta de cobre','lubrificante de cobre']],
  [/\btravoes\b/, /\b(?:limp\w*|desengordurante)\b/, ['limpa travões','produto de limpeza para travões']],
  [/\bjantes?\b/, /\b(?:limp\w*|lava\w*|detergente)\b/, ['limpa jantes','detergente para jantes']],
  [/\b(?:parabrisas|para brisas|limpa vidros)\b/, /\b(?:escova|lamina)s?\b/, ['escova limpa para-brisas','escova limpa-vidros']],
  [/\b(?:desgripante|desbloqueante|penetrante)\b/, /./, ['desgripante','óleo penetrante','desbloqueante']],
  [/\b(?:calcado|sapatos?|botas?)\b/, /\b(?:trabalho|seguranca|protecao|s[123]\w*)\b/, ['calçado de segurança','sapatos de segurança']],
  [/\brebites?\b/, /\b(?:cego|pop)s?\b/, ['rebite cego','rebite de tração']],
  [/\b(?:abracadeira|bracadeira)s?\b/, /\b(?:nylon|plastico|poliamida|cablagem)\b/, ['abraçadeira de cabos','abraçadeira de nylon']],
  [/\b(?:roscas?|parafusos?)\b/, /\b(?:fixador|trava|bloqueador|freio)\b/, ['fixador de roscas','travão de roscas']]
];
function wurthQueries(name) {
  const clean = name.replace(/\b\d+(?:[.,]\d+)?\s*(?:ml|kg|litros?|gramas?|g|l)\b/gi,' ').replace(/\s+/g,' ').trim();
  const key = clean.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ');
  const group = wurthTerms.find(([kind,use]) => kind.test(key) && use.test(key));
  const queries = new Set([clean || name,...(group ? group[2] : [])]);
  if (!group) {
    for (const [pattern, synonyms] of [[/\b(?:massa|pasta)\b/i,['massa','pasta']], [/\b(?:vedante|selante|mastique)\b/i,['vedante','selante','mastique']], [/\b(?:cola|adesivo)\b/i,['cola','adesivo']], [/\b(?:broca|verruma)\b/i,['broca','verruma']], [/\b(?:spray|aerossol)\b/i,['spray','aerossol']]]) {
      if (pattern.test(clean)) for (const term of synonyms) queries.add(clean.replace(pattern,term));
    }
  }
  return [...new Map([...queries].map(term=>[term.toLocaleLowerCase('pt'),term])).values()];
}
function candidateLink(brand, name) {
  const query = name.replace(/\bblinker\b/gi,'').trim();
  const routes = {
    'Würth':'https://eshop.wurth.pt/is-bin/INTERSHOP.enfinity/WFS/3124-B1-Site/pt_PT/-/EUR/ViewAfterSearch-ExecuteAfterSearch?VisibleSearchTerm=',
    'Berner':'https://shop.berner.eu/pt-pt/search?text=',
    'Förch':'https://www.forch.pt/search/'
  };
  if (brand === 'Würth') return '<p>Pesquisar por designações alternativas na Würth Portugal</p>'+wurthQueries(query).map(term=>'<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(routes[brand]+encodeURIComponent(term))+'">'+esc(term)+' ↗</a>').join(' ');
  return '<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(routes[brand]+encodeURIComponent(query))+'">Pesquisar no catálogo '+brand+' Portugal ↗</a>';
}
function nameWords(value) {
  const canonical = norm(value)
    .replace(/\b(?:pasta de limpeza (?:para |de )?maos|limpeza de maos|(?:lava|lavar|limpa)[ -]+(?:as )?maos|sabonete (?:para |de )?maos)\b/g,'lava maos')
    .replace(/\b(?:lubrificante de cobre|cu 800)\b/g,'massa de cobre')
    .replace(/\b(?:mastique|selantes?)\b/g,'vedante')
    .replace(/\b(?:desbloqueante|oleo penetrante)\b/g,'desgripante')
    .replace(/\baerosso(?:l|is)\b/g,'spray');
  return canonical.split(' ').filter(w=>w && !['a','o','de','do','da','dos','das','para','em'].includes(w)).map(w=>w==='pasta'?'massa':stem(w));
}
const nameIndex = PRODUCTS.map(p=>({p,words:new Set(nameWords(p[1]))}));
const eqBrands = ['Würth', 'Berner', 'Förch'];
const eqRefs = new Map(PRODUCTS.map(p => [String(p[0]), p]));
const eqCompact = s => String(s).trim().replace(/[\s.\-/]/g, '').toLowerCase();
const eqCompactRefs = new Map();
for (const p of PRODUCTS) {
  const key = eqCompact(p[0]);
  if (!eqCompactRefs.has(key)) eqCompactRefs.set(key, []);
  eqCompactRefs.get(key).push(p);
}
const eqNav = document.createElement('button');
eqNav.textContent = 'Equivalências';
eqNav.onclick = () => show('equiv');
document.querySelector('nav').append(eqNav);
document.querySelector('nav').style.flexWrap = 'wrap';
const eqSection = document.createElement('section');
eqSection.id = 'equiv';
eqSection.className = 'hide';
eqSection.innerHTML = `<div class="panel"><span class="badge">BLINKER → WÜRTH · BERNER · FÖRCH</span><h2>Equivalências de produtos</h2><p>Introduz o nome ou o código Blinker para consultar correspondências e diferenças técnicas.</p><form id="eqForm"><label for="eqCode">Nome ou código Blinker</label><div class="row" style="margin-top:8px"><input id="eqCode" type="search" autocomplete="off" placeholder="Ex.: massa de cobre ou 04519" required><button class="primary" type="submit">Comparar produto</button></div></form><p class="muted">Comparações documentadas: <a href="#equivalencias/04548210">04548210 · Massa lava mãos Plus</a> e <a href="#equivalencias/0130502">0130502 · Pilha CR2032</a>. Também podes pesquisar massa de cobre ou outro produto pelo nome.</p></div><div id="eqResult" aria-live="polite"></div>`;
document.querySelector('main').append(eqSection);
const forwardPanel = eqSection.firstElementChild;
const reversePanel = document.createElement('div');
reversePanel.className = 'panel';
reversePanel.innerHTML = `<h2>Encontrar o produto Blinker</h2>
<form id="reverseForm"><label for="reverseCode">Referência Würth, Berner ou Förch</label>
<div class="row"><input type="search" id="reverseCode" placeholder="Ex.: 147707 ou 6510 5000" required>
<button class="primary">Procurar na Blinker</button></div></form>
<div id="reverseResult" aria-live="polite"></div>`;
const switcher = document.createElement('nav');
switcher.setAttribute('aria-label','Sentido da comparação');
eqSection.prepend(switcher);
eqSection.append(reversePanel);
function setDirection(reverse) {
  forwardPanel.hidden = reverse;
  document.getElementById('eqResult').hidden = reverse;
  reversePanel.hidden = !reverse;
  Array.from(switcher.children).forEach((button,i) => {
    const active = Boolean(i) === reverse;
    button.setAttribute('aria-pressed',String(active)); button.classList.toggle('primary',active);
  });
}
for (const [i,label] of ['Blinker → Concorrência','Concorrência → Blinker'].entries()) {
  const button = document.createElement('button');
  button.type='button'; button.textContent=label; button.onclick=()=>setDirection(Boolean(i));
  switcher.append(button);
}
setDirection(false);
function reverseMatches(code) {
  const key=eqCompact(code);
  return key ? EQUIVALENCES.filter(record=>eqCompact(record.code)===key && eqRefs.has(record.blinkerCode)) : [];
}
function renderReverse(code) {
  const result=document.getElementById('reverseResult');
  const records=reverseMatches(code);
  if (records.length) {
    result.innerHTML=records.map(r=>{
      const product=eqRefs.get(r.blinkerCode);
      return '<article class="panel"><p>'+esc(r.brand)+' '+esc(r.code)+' · '+esc(r.name)+'</p>'+
        '<h3>Blinker '+esc(product[0])+' · '+esc(product[1])+'</h3><span class="badge">'+esc(r.status)+'</span>'+
        '<p>'+esc(r.application)+'</p><p>'+esc(r.differences)+'</p>'+
        r.sources.map(s=>'<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(s.url)+'">'+esc(s.label)+' ↗</a>').join('')+'</article>';
    }).join('');
    return;
  }
  result.innerHTML='<p>Referência sem comparação documentada. Pesquisa o nome ou as características do produto para encontrar candidatos no catálogo Blinker.</p><form id="reverseByName"><label for="reverseName">Designação do produto concorrente</label><div class="row"><input required id="reverseName" placeholder="Ex.: pasta de cobre"><button>Procurar candidatos</button></div></form><div id="reverseCandidates" aria-live="polite"></div>';
  document.getElementById('reverseByName').onsubmit=e=>{
    e.preventDefault();
    const words=nameWords(document.getElementById('reverseName').value);
    const items=words.length ? nameIndex.filter(entry=>words.every(w=>entry.words.has(w))) : [];
    const list=document.getElementById('reverseCandidates');
    list.replaceChildren();
    list.append(items.length ? 'Candidatos por descrição · confirmar aplicação e especificações ('+items.length+').' : 'Sem resultados. Experimenta o nome do produto sem a marca e sem a embalagem.');
    for (const {p} of items.slice(0,40)) {
      const item=document.createElement('button');
      item.type='button'; item.style.display='block'; item.textContent='Blinker '+p[0]+' · '+p[1]; item.onclick=()=>detail(p[0]); list.append(item);
    }
    if(items.length>40) list.append('Mostram-se os primeiros 40. Refina a descrição.');
  };
}
document.getElementById('reverseForm').onsubmit=e=>{e.preventDefault();renderReverse(document.getElementById('reverseCode').value);};

const eqOriginalShow = show;
show = function(id) {
  eqOriginalShow(id);
  eqSection.classList.toggle('hide', id !== 'equiv');
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('primary', b.textContent === ({prod:'Produtos',cats:'Catálogos visuais',equiv:'Equivalências'}[id])));
};
function eqSearch(code) {
  const exact = eqRefs.get(String(code).trim());
  const candidates = exact ? [exact] : [...(eqCompactRefs.get(eqCompact(code)) || [])];
  const result = document.getElementById('eqResult');
  if (!candidates.length && /[a-zÀ-ÿ]/i.test(code)) {
    const terms = nameWords(code);
    if (terms.length) candidates.push(...nameIndex.filter(e=>terms.every(w=>e.words.has(w))).map(e=>e.p));
  }
  if (candidates.length !== 1) {
    result.replaceChildren();
    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.textContent = candidates.length ? 'Escolhe o produto ('+candidates.length+' resultados). ' : 'Nenhum produto encontrado. Experimenta uma palavra mais curta ou o código completo.';
    for (const item of candidates.slice(0,40)) {
      const button = document.createElement('button');
      button.type='button'; button.textContent=item[0]+' · '+item[1]; button.style.display='block';
      button.onclick=()=>openEquivalences(item[0]); panel.append(button);
    }
    if (candidates.length>40) panel.append('Mostram-se os primeiros 40. Acrescenta uma palavra para restringir a pesquisa.');
    result.append(panel); return;
  }
  const p = candidates[0];
  const matches = EQUIVALENCES.filter(r => r.blinkerCode === String(p[0]));
  result.innerHTML = '<div class="panel"><h3>'+esc(p[1])+'</h3><p>Referência Blinker <strong>'+esc(p[0])+'</strong></p>'+familyBadges(p[0])+'</div><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr))">'+eqBrands.map(brand => {
    const records = matches.filter(r => r.brand === brand);
    return '<article class="panel"><h3>'+esc(brand)+'</h3>'+(records.length ? records.map(r => '<span class="badge">'+esc(r.status)+'</span><h4>'+esc(r.name)+'</h4><p>Referência: <strong>'+esc(r.code)+'</strong></p><p>'+esc(r.application)+'</p><p><strong>Diferenças:</strong> '+esc(r.differences)+'</p><p class="muted">Verificado em '+esc(r.checkedAt)+'</p>'+r.sources.filter(s => /^https:\/\//.test(s.url)).map(s => '<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(s.url)+'">'+esc(s.label)+' ↗</a>').join('')).join('') : '<span class="badge">Por confirmar</span><p>Sem correspondência documentada. Consulta os resultados da pesquisa antes de propor uma alternativa.</p>')+candidateLink(brand,({'04548210':'lava mãos','04519':'spray de cobre','04520':'pasta de cobre','0130502':'CR2032'})[p[0]] || p[1])+'</article>';
  }).join('')+'</div><div class="panel"><strong>Como validar uma alternativa</strong><p>Comparar aplicação, composição ou material, dimensões, normas, homologações e embalagem. Uma designação semelhante não confirma equivalência.</p><button id="eqCopy" type="button">Copiar pedido de comparação</button><p id="eqCopyState" class="muted" role="status"></p></div>';
  document.getElementById('eqCopy').onclick = async () => {
    const text = 'Comparar Blinker '+p[0]+' — '+p[1]+' com Würth, Berner e Förch. Indicar referências, aplicação, diferenças, fichas técnicas oficiais e grau de correspondência. Não inventar equivalências.';
    try { await navigator.clipboard.writeText(text); document.getElementById('eqCopyState').textContent = 'Pedido copiado. Podes colá-lo na conversa para pedir a validação.'; }
    catch { document.getElementById('eqCopyState').textContent = text; }
  };
}
document.getElementById('eqForm').onsubmit = e => { e.preventDefault(); eqSearch(document.getElementById('eqCode').value); };
function openEquivalences(ref) {
  closeModal(); show('equiv'); setDirection(false); document.getElementById('eqCode').value = ref; eqSearch(ref); eqSection.scrollIntoView({behavior:'smooth'});
}
const eqOriginalDetail = detail;
detail = function(ref) {
  eqOriginalDetail(ref);
  const dialog = document.querySelector('.dialog');
  if (!dialog) return;
  const button = document.createElement('button');
  button.className = 'primary'; button.style.cssText = 'width:100%;margin-top:12px';
  button.textContent = 'Comparar com Würth, Berner e Förch';
  button.onclick = () => openEquivalences(ref);
  dialog.append(button);
};
function openComparisonLink() {
  if (location.hash === '#concorrencia') { show('equiv'); setDirection(true); return; }
  const ref = location.hash.match(/^#equivalencias\/([a-z0-9_-]+)$/i)?.[1];
  if (ref && eqRefs.has(ref)) openEquivalences(ref);
}
window.addEventListener('hashchange', openComparisonLink);
show('prod');
openComparisonLink();

