/* Revisão documental em testes; nenhuma equivalência integral confirmada. */
const EQUIVALENCES = [{"brand":"Würth","code":"0827 082 032","blinkerCode":"0130502","name":"Pilha de lítio CR2032","status":"Alternativa para a mesma aplicação","application":"Dispositivos que especificam CR2032 de lítio, 3 V e dimensões compatíveis.","differences":"Formato, química, tensão e dimensões coincidem na documentação; capacidade, corrente, duração e embalagem não foram comparadas.","checkedAt":"13/11/2026","sources":[{"label":"Blinker · Pilhas botão lítio","url":"https://blinkergroup.com/pt-pt/pilhas-botao-litio/"},{"label":"Würth · Pilas botón · ficha 13 04 0022","url":"https://www.wurth.es/media/catalog/productdownloads/1/3/13_04_0022.pdf"}],"classification":"alternative","evidence":[{"text":"Blinker 0130502: CR2032, lítio, 3 V, 20,0 × 3,2 mm.","sources":["b-battery"]},{"text":"Würth 0827 082 032: os mesmos quatro parâmetros.","sources":["w-battery"]}],"unverified":["Capacidade e corrente admissível","Condições de utilização do aparelho","Disponibilidade e embalagem em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["b-battery","w-battery"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"brand":"Berner","code":"198891","blinkerCode":"0130502","name":"Pilha de lítio CR2032","status":"Correspondência por verificar","application":"Candidato para aparelhos que pedem CR2032; não autorizar substituição sem ficha acessível.","differences":"O índice oficial identifica a referência, mas a ficha completa devolveu HTTP 429 nesta revisão.","checkedAt":"13/11/2026","sources":[{"label":"Berner · Energizer CR2032 · 198891","url":"https://shop.berner.eu/de-de/p/198624-lithium-knopfzellen-von-energizer-lithium-cr-serie.html?article_id=198891"},{"label":"Blinker · Pilhas botão lítio","url":"https://blinkergroup.com/pt-pt/pilhas-botao-litio/"}],"classification":"pending","evidence":[{"text":"O índice de pesquisa da página Berner associa 198891 a Energizer CR2032.","sources":["be-battery"]},{"text":"A Blinker documenta CR2032, 3 V e 20,0 × 3,2 mm.","sources":["b-battery"]}],"unverified":["Ficha técnica completa do artigo Berner","Tensão, dimensões, capacidade e corrente confirmadas na ficha","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-battery","b-battery"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"brand":"Förch","code":"3882 2032","blinkerCode":"0130502","name":"Pilha de lítio CR2032","status":"Alternativa para a mesma aplicação","application":"Dispositivos que especificam CR2032 de 3 V; confirmar requisitos elétricos do aparelho.","differences":"O título indexado da página oficial confirma formato e tensão. Não foi validada a capacidade, corrente nem a embalagem portuguesa.","checkedAt":"13/11/2026","sources":[{"label":"Förch · CR2032 3 V · 3882 2032","url":"https://www.forch.com.au/3882-2032-coin-battery-cr-2032-3v"},{"label":"Blinker · Pilhas botão lítio","url":"https://blinkergroup.com/pt-pt/pilhas-botao-litio/"}],"classification":"alternative","evidence":[{"text":"Página Förch indexada: 3882 2032, CR2032, 3 V.","sources":["f-battery"]},{"text":"Blinker: CR2032 de 3 V; dimensões 20,0 × 3,2 mm.","sources":["b-battery"]}],"unverified":["Ficha dimensional e elétrica completa da Förch","Capacidade e corrente admissível","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-battery","b-battery"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Würth","code":"08939055","name":"Massa lava-mãos Tradicional · 4 L","application":"Limpeza das mãos em ambiente profissional; confirmar o tipo de sujidade.","differences":"Würth: 4 L e aroma a limão. Blinker: 4 L e lavanda. Composições e eficácia comparativa não demonstradas.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Würth · Massa lava-mãos Tradicional","url":"https://eshop.wurth.pt/Categorias-de-Produto/Pasta-de-limpeza-tradicional-para-maos/31240502020229.cyid/3124.cgid/pt/PT/EUR/"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Würth 08939055: 4000 ml, limão, abrasivo natural.","sources":["w-traditional"]},{"text":"Blinker 04548210: 4 L, lavanda e abrasivos naturais.","sources":["b-hands"]}],"unverified":["Composição e desempenho para a sujidade concreta","Compatibilidade com doseadores"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["w-traditional","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Würth","code":"0893900059","name":"Massa branca Plastic Free · 5 L","application":"Limpeza profissional das mãos; não pressupõe composição idêntica à Blinker.","differences":"Würth: 5 L com microesferas minerais. Blinker: 4 L com abrasivos naturais; ambas referem lavanda.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Würth · Massa branca Plastic Free","url":"https://eshop.wurth.pt/Categorias-de-Produto/Pasta-de-limpeza-para-maos-livre-de-microplastico/31243007230495.cyid/3124.cgid/pt/PT/EUR/"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Würth 0893900059: 5000 ml, lavanda, microesferas minerais.","sources":["w-plastic"]},{"text":"Blinker: 4 L, lavanda e abrasivos naturais.","sources":["b-hands"]}],"unverified":["Composição e desempenho comparativo","Doseamento e dispensador"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["w-plastic","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Berner","code":"1000578","name":"Fresh & Clean","application":"Limpeza diária das mãos na indústria e no setor automóvel.","differences":"A página Portugal suporta a aplicação geral; não se converte peso em volume nem se assume a mesma embalagem da Blinker.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Berner · Fresh & Clean · 1000578","url":"https://shop.berner.eu/pt-pt/p/55067-pasta-lava-maos-fresh-clean-pasta.html?article_id=1000578"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Berner identifica 1000578 e aplicação na limpeza diária de mãos na indústria/automóvel.","sources":["be-fresh"]},{"text":"Blinker indica limpeza de óleos, gorduras e sujidade persistente.","sources":["b-hands"]}],"unverified":["Embalagem exata e unidade comercial Berner","Eficácia para tintas e poliuretanos na aplicação concreta"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-fresh","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Berner","code":"362812","name":"Lava mãos Pro Bio","application":"Remoção de sujidade industrial das mãos, dentro das indicações da respetiva ficha.","differences":"Berner instrui aplicar em mãos secas e depois juntar água; Blinker instrui mãos previamente humedecidas. Não transferir instruções entre marcas.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Berner · Pro Bio · 362812","url":"https://shop.berner.eu/pt-pt/p/25731915-lava-maos-pro-bio.html?article_id=362812"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Berner 362812: abrasivos de milho, remoção de óleos/gorduras e utilização sobre mãos secas.","sources":["be-pro"]},{"text":"Blinker 04548210: mãos previamente humedecidas.","sources":["b-hands"]}],"unverified":["Embalagem e doseador exatos","Composição e eficácia comparativa"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-pro","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Förch","code":"6180 9139","name":"Derma Top E · 3 L","application":"Produto de limpeza das mãos; aplicação específica por confirmar.","differences":"A página apresenta Derma Top no título, mas Derma Plus na descrição. A FDS confirma a família Derma Top, sem resolver a descrição técnica trocada.","status":"Correspondência por verificar","checkedAt":"13/11/2026","sources":[{"label":"Förch · Derma Top E · 6180 9139","url":"https://www.forch.com.au/6180-9139-derma-top-e-hand-cleaner-3l"},{"label":"Förch · FDS da família de produtos de limpeza de mãos","url":"https://www.forch.com.au/Images/SDS/Forch%20Derma%20Plus%20Lotion%201Ltr%206180%209051.pdf"}],"classification":"pending","evidence":[{"text":"Título e código: Derma Top E, 6180 9139, 3 L; corpo da página menciona Derma Plus.","sources":["f-top"]},{"text":"FDS da família associa 6180 9139 a Derma Top.","sources":["f-hands-sds"]}],"unverified":["Ficha técnica específica e coerente do artigo","Tipo de abrasivo, pH e sujidades removidas","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-top","f-hands-sds"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Förch","code":"6180 9173","name":"Derma Craft E · 3 L","application":"Limpeza de tintas, adesivos, resinas e outra sujidade persistente das mãos.","differences":"Förch: 3 L, face aos 4 L Blinker. Não foi demonstrada equivalência de composição ou do doseador.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Förch · Derma Craft E · 6180 9173","url":"https://www.forch.com.au/6180-9173-derma-craft-e-hand-clean-3lt"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Página oficial: 6180 9173, 3 L, limpeza de tintas/adesivos/resinas e abrasivos naturais.","sources":["f-craft"]},{"text":"Blinker: 4 L e remoção de óleos, gorduras e tintas.","sources":["b-hands"]}],"unverified":["Composição, doseamento e modo de uso detalhado","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-craft","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Würth","code":"0893960004","name":"Xtreme · 4 L","application":"Limpeza das mãos com tintas, gorduras e resíduos de PU previstos na ficha Würth.","differences":"Würth Xtreme: 4 L e aplicação em mãos secas; Blinker: 4 L e aplicação em mãos humedecidas.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Würth · Xtreme · 0893960004","url":"https://www.wurth.es/pasta-lavamanos-xtreme-4l-1"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Würth 0893960004: 4 L; a página refere tintas, PU e gorduras; aplicar nas mãos secas.","sources":["w-xtreme"]},{"text":"Blinker instrui aplicar sobre mãos previamente humedecidas.","sources":["b-hands"]}],"unverified":["Composição e eficácia comparativa","Disponibilidade do artigo em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["w-xtreme","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Berner","code":"424215","name":"Pasta lava mãos II · 4 L","application":"Limpeza das mãos em oficinas e indústria para sujidades indicadas na ficha Berner.","differences":"Berner: balde de 4 L e aroma cítrico; Blinker: 4 L e lavanda. Não se assume fórmula ou rendimento idênticos.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Berner · Pasta lava mãos II · 424215","url":"https://shop.berner.eu/pt-pt/p/55868776-pasta-lava-maos-ii-balde.html?article_id=424215"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Berner 424215: balde 4 L, aroma cítrico, limpeza de óleo, gordura, tintas e resinas.","sources":["be-ii"]},{"text":"Blinker 04548210: 4 L e aroma a lavanda.","sources":["b-hands"]}],"unverified":["Eficácia comparativa e doseador","Condições de utilização específicas"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-ii","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04548210","brand":"Förch","code":"6180 9034","name":"Clean and Care · 10 L","application":"Remoção de óleos e gorduras das mãos, sem alargar a conclusão a poliuretanos.","differences":"Förch: 10 L, partículas de madeira e aroma cítrico; Blinker: 4 L e lavanda. Uso contra PU/tintas não confirmado pela fonte consultada.","status":"Alternativa para a mesma aplicação","checkedAt":"13/11/2026","sources":[{"label":"Förch · Clean & Care · 6180 9034","url":"https://www.forch.com.au/6180-9034-handwash-clean-and-care-10ltr"},{"label":"Blinker · Massa lava mãos Plus","url":"https://blinkergroup.com/pt-pt/massa-lava-maos-plus/"}],"classification":"alternative","evidence":[{"text":"Página oficial 6180 9034: 10 L, partículas de madeira, remoção de óleos/gorduras e aroma cítrico.","sources":["f-care"]},{"text":"Blinker: 4 L e aplicação que também menciona tintas e poliuretanos.","sources":["b-hands"]}],"unverified":["Eficácia para tintas e poliuretanos","Doseador e disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-care","b-hands"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04519","brand":"Würth","code":"0893 800","name":"CU 800 · spray 300 ml","differences":"Ambos em spray de 300 ml. Würth publica até 800 °C; Blinker refere até 1200 °C. Não usar a temperatura Blinker para selecionar Würth.","status":"Alternativa para a mesma aplicação","application":"Proteção contra gripagem em uniões metálicas, apenas dentro das condições da ficha Würth.","checkedAt":"13/11/2026","sources":[{"label":"Würth · CU800 · ficha 03 05 0120","url":"https://www.wurth.es/media/catalog/productdownloads/0/3/03_05_0120.pdf"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"Würth 0893 800: spray 300 ml, proteção contra gripagem/corrosão e limite publicado de 800 °C.","sources":["w-copper"]},{"text":"Blinker 04519: spray 300 ml e limite superior publicado de 1200 °C.","sources":["b-copper"]}],"unverified":["Materiais, regime térmico e instruções do fabricante do equipamento","Composição e homologações comparáveis"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["w-copper","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04519","brand":"Berner","code":"147707","name":"Spray de cobre · 400 ml","differences":"Berner: spray 400 ml; Blinker: 300 ml. A página Berner refere máximo de lubrificação de 1200 °C; isso não comprova igualdade de composição ou de todo o intervalo de serviço.","status":"Alternativa para a mesma aplicação","application":"Proteção contra gripagem de ligações de aço/ferro indicadas pela Berner.","checkedAt":"13/11/2026","sources":[{"label":"Berner · Spray de cobre · 147707","url":"https://shop.berner.eu/pt-pt/p/14781-lubrificante-deslizante-de-cobre.html?article_id=147707"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"Berner 147707: spray de cobre 400 ml, ligações de aço/ferro e máximo de lubrificação indicado de 1200 °C.","sources":["be-spray"]},{"text":"Blinker 04519: spray de 300 ml.","sources":["b-copper"]}],"unverified":["Regime térmico admissível para a aplicação concreta","Materiais e restrições da ficha técnica específica"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-spray","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04519","brand":"Förch","code":"6510 5000","name":"S425 · spray 300 ml","differences":"A página comercial apresenta 300 ml e 800 °C; a FDS de 11/10/2024 identifica o mesmo código como 400 ml. Não escolher automaticamente uma das embalagens.","status":"Correspondência por verificar","application":"Spray de cobre candidato para proteção contra gripagem; variante de embalagem por esclarecer.","checkedAt":"13/11/2026","sources":[{"label":"Förch · S425 spray · 6510 5000","url":"https://www.forch.com.au/6510-5000-copper-spray-s425-300ml"},{"label":"Förch · S425 spray · FDS 6510 5000","url":"https://www.forch.com.au/Images/SDS/Forch-Copper-Spray-S425-400ml-6510-5000.pdf"}],"classification":"pending","evidence":[{"text":"Página comercial: 6510 5000, 300 ml e limite de 800 °C.","sources":["f-spray"]},{"text":"FDS: o mesmo código 6510 5000 aparece como 400 ml.","sources":["f-spray-sds"]}],"unverified":["Identificação da variante comercial e FDS correspondente","Embalagem correta para Portugal","Condições térmicas e materiais"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-spray","f-spray-sds"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04520","brand":"Förch","code":"6510 5001","name":"S425 · tubo 100 g","differences":"Förch: tubo 100 g; Blinker: lata 800 g. A FDS confirma identidade e uso geral, mas não comprova desempenho térmico igual.","status":"Alternativa para a mesma aplicação","application":"Massa de cobre para lubrificação industrial; confirmar requisitos de temperatura e materiais.","checkedAt":"13/11/2026","sources":[{"label":"Förch · S425 pasta · 6510 5001 e 6510 5002","url":"https://www.forch.com.au/Images/SDS/Forch%20Copper%20Paste%20S425%20100g%206510%205001.pdf"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"Förch 6510 5001: pasta 100 g e uso como massa lubrificante industrial na FDS.","sources":["f-paste"]},{"text":"Blinker 04520: embalagem de 800 g.","sources":["b-copper"]}],"unverified":["Temperatura de serviço em ficha técnica específica","Materiais e homologações","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-paste","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04520","brand":"Würth","code":"0893 800 2","name":"CU 800 · lata 1 kg","differences":"Würth: lata 1000 g e limite publicado de 800 °C; Blinker: 800 g e limite superior de 1200 °C. Não são equivalências térmicas.","status":"Alternativa para a mesma aplicação","application":"Proteção contra gripagem em uniões metálicas dentro das condições Würth.","checkedAt":"13/11/2026","sources":[{"label":"Würth · CU800 · ficha 03 05 0120","url":"https://www.wurth.es/media/catalog/productdownloads/0/3/03_05_0120.pdf"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"Würth 0893 800 2: lata 1000 g; ficha CU800 indica até 800 °C.","sources":["w-copper"]},{"text":"Blinker 04520: 800 g e limite superior publicado de 1200 °C.","sources":["b-copper"]}],"unverified":["Materiais e regime térmico da aplicação","Composição e homologações"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["w-copper","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04520","brand":"Berner","code":"399269","name":"Pasta de cobre · 100 g","differences":"Berner: 100 g; Blinker: 800 g. A fonte Berner proíbe uso em alumínio e em sistemas ABS/ASR/ESP; estas restrições não podem ser omitidas.","status":"Alternativa para a mesma aplicação","application":"Proteção contra gripagem em uniões de aço/ferro permitidas pela ficha Berner.","checkedAt":"13/11/2026","sources":[{"label":"Berner · Pasta de cobre · 399269","url":"https://shop.berner.eu/es-es/p/14781-lubricante-deslizante-de-cobre.html?article_id=399269"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"Berner 399269: pasta 100 g, para aço/ferro, com restrições a alumínio e sistemas ABS/ASR/ESP.","sources":["be-paste"]},{"text":"Blinker 04520: 800 g.","sources":["b-copper"]}],"unverified":["Regime térmico e materiais do equipamento","Disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["be-paste","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."},{"blinkerCode":"04520","brand":"Förch","code":"6510 5002","name":"S425 · lata 1 kg","differences":"Förch: 1000 g; Blinker: 800 g. O link comercial antigo devolve 404; foi substituído por FDS oficial que identifica o código. A temperatura da pasta não foi confirmada nesta fonte.","status":"Alternativa para a mesma aplicação","application":"Massa lubrificante industrial de cobre, sujeita a confirmação técnica da aplicação.","checkedAt":"13/11/2026","sources":[{"label":"Förch · S425 pasta · 6510 5001 e 6510 5002","url":"https://www.forch.com.au/Images/SDS/Forch%20Copper%20Paste%20S425%20100g%206510%205001.pdf"},{"label":"Blinker · Pasta de cobre","url":"https://blinkergroup.com/pt-pt/pasta-de-cobre/"}],"classification":"alternative","evidence":[{"text":"FDS oficial identifica 6510 5002 como pasta S425 de 1000 g e uso lubrificante industrial.","sources":["f-paste"]},{"text":"Blinker 04520: lata de 800 g.","sources":["b-copper"]}],"unverified":["Ficha técnica específica e temperatura de serviço","Materiais e disponibilidade em Portugal"],"reviewedAt":"2026-11-13","availability":"Disponibilidade em Portugal não verificada","fullEquivalence":false,"sourceIds":["f-paste","b-copper"],"reviewReason":"Comparação documental; sem ensaios de desempenho nem aprovação de substituição pelo fabricante do equipamento."}];

function reviewEvidence(r) {
 return '<div class="eq-evidence"><strong>Base documental</strong><ul>'+r.evidence.map(f=>'<li>'+esc(f.text)+'</li>').join('')+'</ul><strong>Por confirmar</strong><ul>'+r.unverified.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ul><p class="muted">'+esc(r.availability)+' · '+esc(r.reviewReason)+'</p></div>';
}
const wurthTerms = [
  [/\b(?:maos?|mao)\b/, /\b(?:lava\w*|limp\w*|pasta|massa|sabao|sabonete)\b/, ['pasta de limpeza para mãos','massa lava-mãos','limpeza de mãos']],
  [/\bcobre\b/, /\b(?:massa|pasta|spray|lubrificante|antigripante)\b/, ['CU 800','pasta de cobre','lubrificante de cobre']],
  [/\btravoes\b/, /\b(?:limp\w*|desengordurante)\b/, ['limpa travões','produto de limpeza para travões']],
  [/\bjantes?\b/, /\b(?:limp\w*|lava\w*|detergente)\b/, ['limpa jantes','detergente para jantes']],
  [/\b(?:parabrisas|para brisas|limpa vidros)\b/, /\b(?:escova|lamina)s?\b/, ['escova limpa para-brisas','escova limpa-vidros']],
  [/\b(?:desgripante|desbloqueante|penetrante)\b/, /./, ['desgripante','óleo penetrante','desbloqueante']],
  [/\b(?:calcado|sapatos?|botas?)\b/, /\b(?:trabalho|seguranca|protecao|s[123]\w*)\b/, ['calçado de segurança','sapatos de segurança']],
  [/\brebites?\b/, /\b(?:cego|pop)s?\b/, ['rebite cego','rebite de tração']],
  [/\b(?:abracadeira|bracadeira)s?\b/, /\b(?:nylon|plastico|poliamida|cablagem)\b/, ['abraçadeira de cabos','abraçadeira de nylon']],
  [/\b(?:roscas?|parafusos?)\b/, /\b(?:fixador|trava|bloqueador|freio)\b/, ['fixador de roscas','travão de roscas']]
];
function wurthQueries(name) {
  const clean = name.replace(/\b\d+(?:[.,]\d+)?\s*(?:ml|kg|litros?|gramas?|g|l)\b/gi,' ').replace(/\s+/g,' ').trim();
  const key = clean.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ');
  const group = wurthTerms.find(([kind,use]) => kind.test(key) && use.test(key));
  const queries = new Set([clean || name,...(group ? group[2] : [])]);
  if (!group) {
    for (const [pattern, synonyms] of [[/\b(?:massa|pasta)\b/i,['massa','pasta']], [/\b(?:vedante|selante|mastique)\b/i,['vedante','selante','mastique']], [/\b(?:cola|adesivo)\b/i,['cola','adesivo']], [/\b(?:broca|verruma)\b/i,['broca','verruma']], [/\b(?:spray|aerossol)\b/i,['spray','aerossol']]]) {
      if (pattern.test(clean)) for (const term of synonyms) queries.add(clean.replace(pattern,term));
    }
  }
  return [...new Map([...queries].map(term=>[term.toLocaleLowerCase('pt'),term])).values()];
}
function candidateLink(brand, name) {
  const query = name.replace(/\bblinker\b/gi,'').trim();
  const routes = {
    'Würth':'https://eshop.wurth.pt/is-bin/INTERSHOP.enfinity/WFS/3124-B1-Site/pt_PT/-/EUR/ViewAfterSearch-ExecuteAfterSearch?VisibleSearchTerm=',
    'Berner':'https://shop.berner.eu/pt-pt/search?text=',
    'Förch':'https://www.forch.pt/search/'
  };
  if (brand === 'Würth') return '<p>Pesquisar por designações alternativas na Würth Portugal</p>'+wurthQueries(query).map(term=>'<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(routes[brand]+encodeURIComponent(term))+'">'+esc(term)+' ↗</a>').join(' ');
  return '<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(routes[brand]+encodeURIComponent(query))+'">Pesquisar no catálogo '+brand+' Portugal ↗</a>';
}
function nameWords(value) {
  const canonical = norm(value)
    .replace(/\b(?:pasta de limpeza (?:para |de )?maos|limpeza de maos|(?:lava|lavar|limpa)[ -]+(?:as )?maos|sabonete (?:para |de )?maos)\b/g,'lava maos')
    .replace(/\b(?:lubrificante de cobre|cu 800)\b/g,'massa de cobre')
    .replace(/\b(?:mastique|selantes?)\b/g,'vedante')
    .replace(/\b(?:desbloqueante|oleo penetrante)\b/g,'desgripante')
    .replace(/\baerosso(?:l|is)\b/g,'spray');
  return canonical.split(' ').filter(w=>w && !['a','o','de','do','da','dos','das','para','em'].includes(w)).map(w=>w==='pasta'?'massa':stem(w));
}
const nameIndex = PRODUCTS.map(p=>({p,words:new Set(nameWords(p[1]))}));
const eqBrands = ['Würth', 'Berner', 'Förch'];
const eqRefs = new Map(PRODUCTS.map(p => [String(p[0]), p]));
const eqCompact = s => String(s).trim().replace(/[\s.\-/]/g, '').toLowerCase();
const eqCompactRefs = new Map();
for (const p of PRODUCTS) {
  const key = eqCompact(p[0]);
  if (!eqCompactRefs.has(key)) eqCompactRefs.set(key, []);
  eqCompactRefs.get(key).push(p);
}
const eqNav = document.createElement('button');
eqNav.textContent = 'Equivalências';
eqNav.onclick = () => show('equiv');
document.querySelector('nav').append(eqNav);
document.querySelector('nav').style.flexWrap = 'wrap';
const eqSection = document.createElement('section');
eqSection.id = 'equiv';
eqSection.className = 'hide';
eqSection.innerHTML = `<div class="panel"><span class="badge">BLINKER → WÜRTH · BERNER · FÖRCH</span><h2>Equivalências de produtos</h2><p>Introduz o nome ou o código Blinker para consultar correspondências e diferenças técnicas.</p><form id="eqForm"><label for="eqCode">Nome ou código Blinker</label><div class="row" style="margin-top:8px"><input id="eqCode" type="search" autocomplete="off" placeholder="Ex.: massa de cobre ou 04519" required><button class="primary" type="submit">Comparar produto</button></div></form><p class="muted">Comparações documentadas: <a href="#equivalencias/04548210">04548210 · Massa lava mãos Plus</a> e <a href="#equivalencias/0130502">0130502 · Pilha CR2032</a>. Também podes pesquisar massa de cobre ou outro produto pelo nome.</p></div><div id="eqResult" aria-live="polite"></div>`;
document.querySelector('main').append(eqSection);
const forwardPanel = eqSection.firstElementChild;
const reversePanel = document.createElement('div');
reversePanel.className = 'panel';
reversePanel.innerHTML = `<h2>Encontrar o produto Blinker</h2>
<form id="reverseForm"><label for="reverseCode">Referência Würth, Berner ou Förch</label>
<div class="row"><input type="search" id="reverseCode" placeholder="Ex.: 147707 ou 6510 5000" required>
<button class="primary">Procurar na Blinker</button></div></form>
<div id="reverseResult" aria-live="polite"></div>`;
const switcher = document.createElement('nav');
switcher.setAttribute('aria-label','Sentido da comparação');
eqSection.prepend(switcher);
eqSection.append(reversePanel);
function setDirection(reverse) {
  forwardPanel.hidden = reverse;
  document.getElementById('eqResult').hidden = reverse;
  reversePanel.hidden = !reverse;
  Array.from(switcher.children).forEach((button,i) => {
    const active = Boolean(i) === reverse;
    button.setAttribute('aria-pressed',String(active)); button.classList.toggle('primary',active);
  });
}
for (const [i,label] of ['Blinker → Concorrência','Concorrência → Blinker'].entries()) {
  const button = document.createElement('button');
  button.type='button'; button.textContent=label; button.onclick=()=>setDirection(Boolean(i));
  switcher.append(button);
}
setDirection(false);
function reverseMatches(code) {
  const key=eqCompact(code);
  return key ? EQUIVALENCES.filter(record=>eqCompact(record.code)===key && eqRefs.has(record.blinkerCode)) : [];
}
function renderReverse(code) {
  const result=document.getElementById('reverseResult');
  const records=reverseMatches(code);
  if (records.length) {
    result.innerHTML=records.map(r=>{
      const product=eqRefs.get(r.blinkerCode);
      return '<article class="panel"><p>'+esc(r.brand)+' '+esc(r.code)+' · '+esc(r.name)+'</p>'+
        '<h3>Blinker '+esc(product[0])+' · '+esc(product[1])+'</h3><span class="badge">'+esc(r.status)+'</span>'+
        '<p>'+esc(r.application)+'</p><p>'+esc(r.differences)+'</p>'+reviewEvidence(r)+
        r.sources.map(s=>'<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(s.url)+'">'+esc(s.label)+' ↗</a>').join('')+'</article>';
    }).join('');
    return;
  }
  result.innerHTML='<p>Referência sem comparação documentada. Pesquisa o nome ou as características do produto para encontrar candidatos no catálogo Blinker.</p><form id="reverseByName"><label for="reverseName">Designação do produto concorrente</label><div class="row"><input required id="reverseName" placeholder="Ex.: pasta de cobre"><button>Procurar candidatos</button></div></form><div id="reverseCandidates" aria-live="polite"></div>';
  document.getElementById('reverseByName').onsubmit=e=>{
    e.preventDefault();
    const words=nameWords(document.getElementById('reverseName').value);
    const items=words.length ? nameIndex.filter(entry=>words.every(w=>entry.words.has(w))) : [];
    const list=document.getElementById('reverseCandidates');
    list.replaceChildren();
    list.append(items.length ? 'Candidatos por descrição · confirmar aplicação e especificações ('+items.length+').' : 'Sem resultados. Experimenta o nome do produto sem a marca e sem a embalagem.');
    for (const {p} of items.slice(0,40)) {
      const item=document.createElement('button');
      item.type='button'; item.style.display='block'; item.textContent='Blinker '+p[0]+' · '+p[1]; item.onclick=()=>detail(p[0]); list.append(item);
    }
    if(items.length>40) list.append('Mostram-se os primeiros 40. Refina a descrição.');
  };
}
document.getElementById('reverseForm').onsubmit=e=>{e.preventDefault();renderReverse(document.getElementById('reverseCode').value);};

const eqOriginalShow = show;
show = function(id) {
  eqOriginalShow(id);
  eqSection.classList.toggle('hide', id !== 'equiv');
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('primary', b.textContent === ({prod:'Produtos',cats:'Catálogos visuais',equiv:'Equivalências'}[id])));
};
function eqSearch(code) {
  const exact = eqRefs.get(String(code).trim());
  const candidates = exact ? [exact] : [...(eqCompactRefs.get(eqCompact(code)) || [])];
  const result = document.getElementById('eqResult');
  if (!candidates.length && /[a-zÀ-ÿ]/i.test(code)) {
    const terms = nameWords(code);
    if (terms.length) candidates.push(...nameIndex.filter(e=>terms.every(w=>e.words.has(w))).map(e=>e.p));
  }
  if (candidates.length !== 1) {
    result.replaceChildren();
    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.textContent = candidates.length ? 'Escolhe o produto ('+candidates.length+' resultados). ' : 'Nenhum produto encontrado. Experimenta uma palavra mais curta ou o código completo.';
    for (const item of candidates.slice(0,40)) {
      const button = document.createElement('button');
      button.type='button'; button.textContent=item[0]+' · '+item[1]; button.style.display='block';
      button.onclick=()=>openEquivalences(item[0]); panel.append(button);
    }
    if (candidates.length>40) panel.append('Mostram-se os primeiros 40. Acrescenta uma palavra para restringir a pesquisa.');
    result.append(panel); return;
  }
  const p = candidates[0];
  const matches = EQUIVALENCES.filter(r => r.blinkerCode === String(p[0]));
  result.innerHTML = '<div class="panel"><h3>'+esc(p[1])+'</h3><p>Referência Blinker <strong>'+esc(p[0])+'</strong></p>'+familyBadges(p[0])+'</div><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr))">'+eqBrands.map(brand => {
    const records = matches.filter(r => r.brand === brand);
    return '<article class="panel"><h3>'+esc(brand)+'</h3>'+(records.length ? records.map(r => '<span class="badge">'+esc(r.status)+'</span><h4>'+esc(r.name)+'</h4><p>Referência: <strong>'+esc(r.code)+'</strong></p><p>'+esc(r.application)+'</p><p><strong>Diferenças:</strong> '+esc(r.differences)+'</p>'+reviewEvidence(r)+'<p class="muted">Revisão documental em '+esc(r.checkedAt)+'</p>'+r.sources.filter(s => /^https:\/\//.test(s.url)).map(s => '<a class="action" target="_blank" rel="noopener noreferrer" href="'+esc(s.url)+'">'+esc(s.label)+' ↗</a>').join('')).join('') : '<span class="badge">Por confirmar</span><p>Sem correspondência documentada. Consulta os resultados da pesquisa antes de propor uma alternativa.</p>')+candidateLink(brand,({'04548210':'lava mãos','04519':'spray de cobre','04520':'pasta de cobre','0130502':'CR2032'})[p[0]] || p[1])+'</article>';
  }).join('')+'</div><div class="panel"><strong>Como validar uma alternativa</strong><p>Comparar aplicação, composição ou material, dimensões, normas, homologações e embalagem. Uma designação semelhante não confirma equivalência.</p><button id="eqCopy" type="button">Copiar pedido de comparação</button><p id="eqCopyState" class="muted" role="status"></p></div>';
  document.getElementById('eqCopy').onclick = async () => {
    const text = 'Comparar Blinker '+p[0]+' — '+p[1]+' com Würth, Berner e Förch. Indicar referências, aplicação, diferenças, fichas técnicas oficiais e grau de correspondência. Não inventar equivalências.';
    try { await navigator.clipboard.writeText(text); document.getElementById('eqCopyState').textContent = 'Pedido copiado. Podes colá-lo na conversa para pedir a validação.'; }
    catch { document.getElementById('eqCopyState').textContent = text; }
  };
}
document.getElementById('eqForm').onsubmit = e => { e.preventDefault(); eqSearch(document.getElementById('eqCode').value); };
function openEquivalences(ref) {
  closeModal(); show('equiv'); setDirection(false); document.getElementById('eqCode').value = ref; eqSearch(ref); eqSection.scrollIntoView({behavior:'smooth'});
}
const eqOriginalDetail = detail;
detail = function(ref) {
  eqOriginalDetail(ref);
  const dialog = document.querySelector('.dialog');
  if (!dialog) return;
  const button = document.createElement('button');
  button.className = 'primary'; button.style.cssText = 'width:100%;margin-top:12px';
  button.textContent = 'Comparar com Würth, Berner e Förch';
  button.onclick = () => openEquivalences(ref);
  dialog.append(button);
};
function openComparisonLink() {
  if (location.hash === '#concorrencia') { show('equiv'); setDirection(true); return; }
  const ref = location.hash.match(/^#equivalencias\/([a-z0-9_-]+)$/i)?.[1];
  if (ref && eqRefs.has(ref)) openEquivalences(ref);
}
window.addEventListener('hashchange', openComparisonLink);
show('prod');
openComparisonLink();

