# Blinker — fichas documentais de todo o inventário

## Estado real desta entrega

Foi preparado um **registo documental para cada uma das 28.377 referências existentes**. Isso não significa que todas tenham uma ficha técnica completa.

| Estado | Referências |
|---|---:|
| Fichas piloto documentadas manualmente | 4 |
| Rascunhos automáticos de Químicos, por validar | 39 |
| Página associada, ficha técnica parcial | 18.272 |
| Sem página associada nos catálogos processados | 10.062 |
| Total | 28.377 |

Existem páginas associadas a 18.315 referências. A cobertura usa as 3.510 páginas dos quatro catálogos completos disponíveis no projeto: Auto Geral, Manutenção Geral, Car Wash e Roupa 2026–2027. Os restantes títulos da galeria, quando apenas existe capa no projeto, não foram tratados como documentação completa.

O site principal, os preços, a tarifa, as famílias e as equivalências não foram alterados nem publicados. Esta pasta contém uma cópia de testes e um processo reproduzível de inventário e extração.

## Primeiro lote: Químicos

A seleção usa os identificadores de família existentes `01`, `mg-0` e `auto-0`, sem reclassificar produtos pelo nome ou prefixo.

- 3.580 referências no lote.
- 3.578 têm página associada; duas não têm.
- Duas fichas piloto pertencem ao lote: os produtos de cobre. As outras duas fichas piloto permanecem nas suas famílias.
- 39 rascunhos automáticos novos.
- 3.537 registos parciais com fonte, sem atribuição automática de especificações.

As 39 extrações não são fichas aprovadas: são textos separados por títulos para conferência humana. Cada rascunho identifica a página de origem. Antes de o promover a informação técnica de produto, é necessário confrontar a imagem e confirmar que cada afirmação pertence à referência e à variante certas.

## Critérios da extração

Só são candidatos os textos nativos de páginas com uma referência reconhecida, com ocorrência exata da referência no texto, características, aplicação e modo de utilização identificáveis. Secções repetidas, outros códigos numéricos suspeitos, instruções específicas por referência, texto OCR e páginas partilhadas impedem a atribuição automática.

As páginas com várias referências podem conter variantes ou produtos diferentes. A ferramenta não presume que todos partilham características, capacidade, homologações, temperatura ou instruções. Nessas situações apresenta apenas as fontes e mantém a ficha parcial. Uma página original não é apresentada como fotografia individual de todos os produtos nela incluídos.

Dados ausentes não foram completados por estimativas. As fotografias individuais estão verificadas apenas nas quatro fichas piloto herdadas da etapa anterior. Os restantes registos assinalam esse ponto como pendente.

“Sem página associada” é uma lacuna do índice dos quatro catálogos processados, não uma afirmação de que o produto não existe em nenhuma documentação Blinker. As 10.062 referências ficam como lista de trabalho para procurar ou associar fontes.

## Consultar

Abrir `report.html` num navegador moderno. Os filtros e os 39 rascunhos estão incorporados no relatório e funcionam sem rede. Por omissão mostra o lote de Químicos; selecionar “Todo o inventário” para consultar todas as referências. Os links para fichas e páginas originais exigem a cópia completa da aplicação.

Para experimentar essa cópia local, a partir desta pasta:

```sh
python -m http.server 8081 --directory .
```

Abrir `http://localhost:8081/src/`. Todas as referências mantêm a ficha comercial anterior e recebem um estado documental. O módulo carrega apenas o grupo documental necessário quando se abre uma ficha. As quatro fichas piloto preservam o conteúdo detalhado e as fotografias originais. Os restantes produtos mostram fontes, limites da cobertura e, quando existe, o rascunho claramente identificado como não validado.

As ligações `src/#ficha/REFERENCIA` e `src/#fonte/CATALOGO/PAGINA` permitem abrir o produto ou a fonte. Não são ligações da versão pública atual.

## Ficheiros e reprodução

- `inventory-input.json`: snapshot de produtos e famílias da aplicação.
- `inventory.json`: inventário de cobertura, em linhas compactas: referência, designação, preço, embalagem, famílias, estado, pertença ao lote Químicos, número de páginas e primeira fonte.
- `chemical-drafts.json`: os 39 rascunhos e identificadores de fonte.
- `summary.json`: contagens e âmbito; os motivos de rejeição contam pares produto/página, não páginas únicas.
- `src/data/product-documents/`: registos por prefixo de dois caracteres e registo global das fontes.
- `src/product-documents.js`: apresentação do estado e carregamento dos dados, sem substituir os preços.
- `src/product-specs.js`: quatro fichas piloto preservadas.
- `verification.json`, `test-results.txt` e `browser-results.json`: verificações e evidência de integridade.

```sh
node export_inventory.cjs
python build_inventory.py
python make_report.py
python -m unittest -v test_inventory.py
node --check src/product-documents.js
python browser_tests.py
```

O processo usa caminhos locais para a aplicação original e a etapa das quatro fichas piloto; esses caminhos devem ser ajustados noutra máquina. Não contém comandos de publicação. A reconstrução otimizada foi comparada byte a byte com os dados de inventário, rascunhos, aplicação e fontes já testados.

São seis testes de inventário, associação exata, rejeição de páginas ambíguas, integridade e âmbito. Os testes de navegador a 390 e 1280 px cobrem filtros, zeros iniciais, carregamento assíncrono, rascunhos, fichas parciais, falta de fonte, quatro fichas piloto, equivalências e pesquisa atual.

## O que falta para fichas completas

Conferir os 39 rascunhos contra as páginas originais; separar os blocos e variantes das páginas partilhadas; obter/associar documentação para as 10.062 referências sem página; validar fotografias individuais e completar os campos técnicos apenas quando existir evidência. Depois desse controlo, avançar pelos lotes das restantes famílias.

O ZIP de entrega é um pacote de revisão e alterações para aplicar **numa cópia** do projeto. Inclui relatório, dados, código e as fotografias/PDF usados nas quatro fichas piloto. Não inclui os restantes dados comerciais e milhares de imagens dos catálogos, já existentes no backup integral. A cópia completa de testes permanece nesta pasta. Nenhuma ficha parcial ou rascunho foi promovida a ficha técnica validada ou publicada em produção.
