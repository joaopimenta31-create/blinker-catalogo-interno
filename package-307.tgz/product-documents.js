/* Documentary coverage for all products. Automatic extracts remain unreviewed. */
const documentBucketCache=new Map();let documentRegistryPromise;
function documentBucket(ref){return ref.slice(0,2).toUpperCase().replace(/[^A-Z0-9]/g,'_');}
async function readDocumentJson(path){const response=await fetch(path+'?v=documentos-20261113');if(!response.ok)throw Error('Fonte indisponível');return response.json();}
function documentRegistry(){if(!documentRegistryPromise)documentRegistryPromise=readDocumentJson('data/product-documents/sources.json').catch(error=>{documentRegistryPromise=undefined;throw error;});return documentRegistryPromise;}
function productDocumentRecord(ref){const key=documentBucket(ref);if(!documentBucketCache.has(key))documentBucketCache.set(key,readDocumentJson('data/product-documents/'+key+'.json').catch(error=>{documentBucketCache.delete(key);throw error;}));return documentBucketCache.get(key).then(data=>data[ref]);}
const documentStatusLabels={pilot_documented:'Ficha piloto documentada',chemical_draft:'Extração automática de Químicos · por validar',catalog_draft:'Extração automática · por validar',source_variant_documented:'Modelo e tamanho conferidos',source_candidate:'Fonte possível · por confirmar',source_partial:'Ficha documental parcial',no_source:'Sem página técnica associada'};
function documentSourceButton(source){return '<button type="button" class="document-source" onclick="openCatalogPage(\''+source.slug+'\','+source.page+')">'+esc(source.catalogTitle)+' · pág. '+source.page+'</button>';}
function documentReviewHtml(review,registry){
 if(!review)return '';
 const pending=review.status==='needs_manufacturer_confirmation';
 const title=review.status==='rejected_misattribution'?'Atribuição corrigida':pending?'Dados divergentes · confirmação necessária':review.status==='corrected_with_source'?'Correção documentada':'Transcrição conferida com o PDF';
 const facts=(review.resolvedFacts||[]).map(f=>'<li>'+esc(f.text)+' '+(f.url?'<a href="'+esc(f.url)+'" target="_blank" rel="noopener noreferrer">Fonte oficial</a>':documentSourceButton(registry[f.sourceId]))+'</li>').join('');
 return '<div class="document-review '+(pending?'document-review-pending':'')+'"><strong>'+esc(title)+'</strong><p>'+esc(review.finding||review.scope)+'</p>'+(facts?'<ul>'+facts+'</ul>':'')+(pending?'<p>Os valores divergentes não estão aprovados. A transcrição original abaixo é mantida apenas para comparação com a fonte.</p>':'')+'</div>';
}
function documentDraftHtml(draft,registry,review){
 const names={characteristics:'Características',technical:'Dados técnicos',applications:'Aplicações',instructions:'Modo de utilização',limitations:'Limitações',precautions:'Precauções',notes:'Notas'};
 const tables=(draft.tables||[]).map(t=>'<details class="document-table"><summary>Tabela de medidas e valores · transcrição conferida</summary><div class="document-table-scroll"><table><thead><tr>'+t.columns.map(c=>'<th scope="col">'+esc(c)+'</th>').join('')+'</tr></thead><tbody>'+t.rows.map(row=>'<tr>'+row.map(c=>'<td>'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'+(t.note?'<p>'+esc(t.note)+'</p>':'')+documentSourceButton(registry[t.sourceId])+'</details>').join('');
 const body='<div class="document-draft"><strong>Texto documental · transcrição conferida</strong><p>O texto foi conferido com o PDF original. A aplicabilidade técnica, a versão atual e as homologações não ficam aprovadas por esta conferência.</p>'+draft.sections.filter(s=>s.text.trim()).map(s=>'<details><summary>'+esc(names[s.kind]||s.heading)+'</summary><pre>'+esc(s.text)+'</pre>'+documentSourceButton(registry[draft.sourceId])+'</details>').join('')+tables+'</div>';
 return review?.status==='needs_manufacturer_confirmation'?'<details class="document-blocked-text"><summary>Consultar transcrição original com divergências</summary>'+body+'</details>':body;
}
function documentVariantHtml(evidence,registry){
 if(!evidence?.length)return '';
 return '<div class="document-variant"><strong>Correspondência de modelo e tamanho conferida</strong><p>O modelo e o tamanho da designação foram cruzados com a família de referência e o intervalo de tamanhos no mesmo bloco do PDF. Esta confirmação não atribui características, normas ou homologações ao artigo.</p>'+evidence.map(e=>'<p>'+esc(e.model)+' · tamanho '+esc(String(e.size))+' · intervalo impresso '+esc(e.printedRange)+'</p>'+documentSourceButton(registry[e.sourceId])).join('')+'</div>';
}
const documentOriginalDetail=detail;
detail=function(ref){
 if(!PRODUCTS.some(p=>p[0]===ref))return;
 documentOriginalDetail(ref);
 if(PRODUCT_TECH_SHEETS[ref])return;
 const dialog=document.querySelector('.dialog');if(!dialog)return;
 const panel=document.createElement('section');panel.className='global-document-sheet';panel.dataset.reference=ref;
 panel.innerHTML='<h3>Documentação técnica</h3><p>A carregar as fontes da referência '+esc(ref)+'…</p>';
 dialog.querySelector('h3').insertAdjacentElement('afterend',panel);
 Promise.all([productDocumentRecord(ref),documentRegistry()]).then(([record,registry])=>{
  if(!panel.isConnected)return;
  if(!record)throw Error('Registo documental em falta');
  panel.innerHTML='<h3>'+esc(documentStatusLabels[record.status])+'</h3>'+
   (record.status==='no_source'?'<p>Não foi identificada uma página com esta referência nos catálogos processados neste lote. Mantêm-se os dados comerciais; características, utilização, limitações e fotografia individual ficam por confirmar.</p>':record.status==='source_variant_documented'?'<p>A correspondência de modelo e tamanho está documentada nas fontes abaixo. Os dados técnicos mantêm a sua validação separada.</p>':record.status==='source_candidate'?'<p>Ainda não há uma associação direta por código. As possíveis fontes indicadas abaixo exigem confirmação da referência e da variante.</p>':'<p>As páginas abaixo incluem esta referência. Uma página pode conter vários produtos ou variantes: as características e fotografias da página não foram atribuídas automaticamente ao artigo.</p>')+
   '<div>'+record.sources.map(id=>documentSourceButton(registry[id])).join(' ')+'</div>'+documentReviewHtml(record.review,registry)+documentVariantHtml(record.variantSources,registry)+
   (record.draft?documentDraftHtml(record.draft,registry,record.review):'')+
   (record.candidateSources?.length?'<div class="document-draft"><strong>Possíveis fontes · correspondência não confirmada</strong><p>Códigos reconstruídos por família/sufixo ou intervalo de tamanhos. Confirma a variante na imagem: estes candidatos não foram usados para atribuir preços, características ou homologações.</p>'+record.candidateSources.map(id=>documentSourceButton(registry[id])).join(' ')+'</div>':'')+
   '<p class="muted">Fotografia individual não validada neste lote. A imagem original da página, quando disponível, continua acessível. O preço e a embalagem mantêm a origem comercial existente.</p>';
 }).catch(()=>{if(panel.isConnected)panel.innerHTML='<h3>Documentação técnica</h3><p>Não foi possível carregar o registo. Fecha e volta a abrir a ficha para tentar novamente. Não foram inferidos dados técnicos.</p>';});
};
const documentStyle=document.createElement('style');documentStyle.textContent='.global-document-sheet{padding:16px;border:2px solid #e5a264;border-radius:12px;background:#fffdf8;margin:16px 0}.document-source{margin:4px 4px 4px 0;max-width:100%;font-size:13px}.document-draft{background:#fff0da;padding:14px;margin-top:15px;border-left:4px solid #d46a00}.document-draft summary{cursor:pointer;padding:10px 0;font-weight:650}.document-draft pre{font:15px/1.5 system-ui;white-space:pre-wrap;overflow-wrap:anywhere}';document.head.append(documentStyle);
async function openDocumentHash(){
 const product=location.hash.match(/^#ficha\/([A-Za-z0-9_-]+)$/);if(product&&PRODUCTS.some(p=>p[0]===product[1])){detail(product[1]);return;}
 const source=location.hash.match(/^#fonte\/([a-z0-9-]+)\/(\d+)$/);
 if(source){const registry=await documentRegistry(),id=source[1]+':'+Number(source[2]);if(registry[id])openCatalogPage(source[1],Number(source[2]));}
}
window.addEventListener('hashchange',openDocumentHash);openDocumentHash();

const documentReviewLink=document.createElement("a");documentReviewLink.className="action";documentReviewLink.href="revisao-fichas.html";documentReviewLink.textContent="Revisão das fichas";document.querySelector("nav").append(documentReviewLink);

for(const i of [7]){const tile=document.getElementById('catalogs').children[i];if(tile){const note=document.createElement('p');note.className='muted';note.textContent='Só capa · PDF ainda não localizado nas fontes ligadas';tile.append(note);}}

const documentReviewStyle=document.createElement('style');documentReviewStyle.textContent='.document-review,.document-variant{padding:14px;border:1px solid #9cadbb;border-radius:8px;margin-top:14px;background:#f0f5f8}.document-review-pending{border:2px solid #a9471a;background:#fff2e8}.document-blocked-text{padding:12px;border:1px solid #a9471a;border-radius:8px;margin-top:12px}.document-blocked-text>summary{font-weight:700;cursor:pointer}.document-table-scroll{overflow-x:auto}.document-table table{width:100%;border-collapse:collapse}.document-table th,.document-table td{padding:8px;border:1px solid #cbd1d7;text-align:left;white-space:nowrap}.document-table th{background:#f5f6f8}.document-table td{font-size:14px}';document.head.append(documentReviewStyle);
