# Blinker — restantes catálogos e famílias, em testes

## Entrega

Foram localizados no Google Drive e integrados numa cópia independente oito PDFs que anteriormente tinham apenas capa na aplicação:

| Catálogo | Páginas | Separadores navegáveis |
|---|---:|---:|
| Auto Pequeno Material | 240 | 62 do PDF |
| Manutenção Pequeno Material | 219 | 74 do PDF |
| Calçado Sparco | 28 | Sem marcadores identificados |
| Especial Hotéis | 34 | 8 do índice impresso |
| Indústria Alimentar | 41 | 13 do índice impresso |
| Limpa-para-brisas | 18 | Sem marcadores identificados |
| Parafusos | 44 | Sem marcadores identificados |
| Rebites | 3 | Sem marcadores identificados |
| Total novo | 627 | |

A cópia tem agora **12 catálogos completos e 4.137 páginas**, com as imagens originais e os textos disponíveis. Foram reutilizadas 114 imagens de páginas idênticas para evitar duplicação, sem mudar o conteúdo visual. Em PDFs sem marcadores navegáveis identificados, o índice/página original foi preservado; não se inventaram destinos de separadores.

Não foram encontrados PDFs independentes de **Hotelaria** e **Indústria Alimentar II** nas fontes ligadas consultadas. Os dois títulos permanecem com capa e indicação explícita da fonte em falta. O PDF de indústria alimentar encontrado tem título genérico, sem volume I/II identificado na capa; não foi apresentado como dois documentos distintos.

**O site principal não foi alterado nem publicado nesta etapa.**

## Fichas e estados

O inventário continua com as mesmas 28.377 referências, preços e embalagens. A extração conservadora foi estendida às restantes famílias, incluindo as páginas existentes e os novos PDFs:

| Estado | Referências |
|---|---:|
| Fichas piloto documentadas | 4 |
| Rascunhos de Químicos, preservados | 39 |
| Novos rascunhos de outras famílias | 49 |
| Fichas documentais parciais com código direto | 18.926 |
| Sem código direto, mas com possíveis fontes | 1.200 |
| Sem fonte identificada | 8.159 |

Há **19.018 referências com página por código direto**, mais 703 do que na etapa anterior. No total, 3.755 referências têm pelo menos uma possível fonte por confirmar; 2.555 dessas também têm uma página por código direto, pelo que não se devem somar todos esses números como referências distintas.

Os 88 rascunhos automáticos, incluindo os 39 existentes e os 49 adicionais, permanecem por validar. Não são fichas técnicas aprovadas, ensaios de desempenho ou homologações. As fotografias individuais continuam verificadas apenas nas quatro fichas piloto; as novas associações de imagem representam páginas de catálogo.

## Correspondências diretas e candidatas

A importação associa códigos impressos reconhecidos às referências existentes, conservando os zeros iniciais. Códigos em colunas de referência e formas impressas com prefixo separado são tratados como relações documentais diretas, sem criar novos produtos ou valores comerciais.

Nos catálogos de pequeno material, referências formadas por família e sufixo são mantidas **apenas como candidatas**. No Sparco, intervalos impressos como `672084136-48` são expandidos apenas para procurar variantes já existentes no inventário; as 628 candidatas por intervalo de tamanho não receberam automaticamente preço, especificações ou homologações da página.

Uma candidata não altera famílias comerciais, catálogo comercial associado nem a imagem primária. A ficha mostra “Fonte possível · por confirmar” e exige conferir o modelo, tamanho e variante na imagem. Nenhuma referência foi criada por inferência de intervalos.

As 1.231 atualizações de associação a famílias/catálogos usam apenas códigos diretos e preservam todas as associações anteriores. As 703 novas imagens primárias preenchem apenas referências que antes não tinham imagem, sem substituir as existentes. Os preços e as embalagens não foram importados dos novos PDFs: continuam exatamente os da tarifa atual da aplicação.

## Consultar

Abrir `report.html` num navegador moderno. Os filtros, o inventário e os textos dos rascunhos estão incorporados no relatório. É possível filtrar os oito novos PDFs, cada catálogo, os 12 catálogos, a família e o estado documental. A abertura das fichas e páginas originais exige a cópia de testes completa.

Para experimentar a aplicação completa nesta pasta:

```sh
python -m http.server 8081 --directory .
```

Abrir `http://localhost:8081/src/`. Os oito novos cartões da galeria abrem o leitor, e o seletor tem os 12 catálogos. A ligação “Revisão das fichas” apresenta o novo relatório. Os dois cartões sem PDF mantêm essa indicação. As quatro fichas piloto, a pesquisa e as equivalências anteriores foram preservadas.

## Fontes e reprodução

`catalog-sources.json` identifica os oito PDFs, os links originais e os caminhos locais. Os PDFs foram recuperados por ligação autenticada ao Drive; o pacote não contém URLs temporários de download ou credenciais. Os originais permanecem nas pastas locais de anexos/downloads e os SHA-256 estão em `catalog-import-summary.json` e nos índices dos catálogos.

`src/catalogs/` contém páginas e índices. Páginas com texto nativo insuficiente ou só imagem foram assinaladas, incluindo capas e divisórias; não se inventou OCR nem se transferiram características entre produtos da mesma página. `unmatched_code_candidates` pode conter códigos ou medidas não conciliados; não é uma lista de novos produtos confirmados.

```sh
python import_catalogs.py
python integrate.py
python make_report.py
python -m unittest -v test_batch.py
python browser_tests.py
```

Os scripts usam os caminhos locais de origem desta execução e devem ser ajustados noutra máquina. `integrate.py` parte de uma cópia limpa da versão principal; não deve ser repetido sobre uma integração já modificada sem repor a cópia. Nenhum comando de publicação faz parte deste processo.

## Verificação

Oito testes de dados passaram: integridade dos PDFs, paginação, índices originais, existência de imagens, preços e produtos sem alterações, associações aditivas, separação de candidatas, preservação das imagens/fichas/equivalências e integridade do projeto principal.

Os testes de navegador a 390 e 1280 px abriram os oito novos catálogos e verificaram carregamento de páginas/imagens, os filtros de 49 e 39 rascunhos, falta de fonte, candidatas Sparco, apresentação explícita de incerteza, fichas piloto, equivalências e a pesquisa. Não foram encontrados erros JavaScript nem recursos em falta.

## Pacote

O ZIP é uma atualização para revisão/aplicação **numa cópia do projeto atual**, não uma cópia integral independente. Inclui relatório, dados, código alterado e páginas/imagens dos oito novos catálogos. Os PDFs originais e os ficheiros inalterados da aplicação não foram duplicados no pacote. A cópia completa de testes encontra-se nesta pasta. É necessária validação das correspondências e dos rascunhos antes de qualquer promoção a dados técnicos confirmados.
