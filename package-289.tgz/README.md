# Consulta documental Blinker

A coleção tem 12 catálogos completos, 4.137 páginas e as mesmas 28.377 referências comerciais.

Oito PDFs acrescentaram 627 páginas: Auto Pequeno Material, Manutenção Pequeno Material, Calçado Sparco, Especial Hotéis, Indústria Alimentar, Limpa-para-brisas, Parafusos e Rebites. Hotelaria e Indústria Alimentar II continuam sem PDF independente localizado. O PDF encontrado de indústria alimentar não identifica volume I/II.

Há quatro fichas piloto documentadas e 88 rascunhos automáticos por validar: 39 de Químicos e 49 das restantes famílias. A publicação não constitui aprovação de especificações ou homologações.

19.018 referências têm página por código direto. Outras 1.200 têm apenas possíveis fontes por conferir. Permanecem 8.159 sem fonte identificada nos documentos processados. Referências reconstruídas por família/sufixo ou intervalos de tamanhos não foram usadas para atribuir preços ou especificações.

Usa os filtros de catálogo e estado na revisão das fichas. As ligações abrem o produto ou a página original. Os separadores de PDF e os índices impressos identificados foram preservados. Páginas sem marcadores navegáveis continuam acessíveis no leitor.

Os preços e embalagens mantêm a tarifa de 11/11/2026. As fotografias individuais estão verificadas apenas nas quatro fichas piloto; as restantes imagens representam páginas de catálogo. Antes de utilizar um rascunho, confirma a variante e os dados na fonte.
