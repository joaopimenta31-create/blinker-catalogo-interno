/* Documentary coverage for all products. Automatic extracts remain unreviewed. */
const documentBucketCache=new Map();let documentRegistryPromise;
function documentBucket(ref){return ref.slice(0,2).toUpperCase().replace(/[^A-Z0-9]/g,'_');}
async function readDocumentJson(path){const response=await fetch(path);if(!response.ok)throw Error('Fonte indisponível');return response.json();}
function documentRegistry(){if(!documentRegistryPromise)documentRegistryPromise=readDocumentJson('data/product-documents/sources.json').catch(error=>{documentRegistryPromise=undefined;throw error;});return documentRegistryPromise;}
function productDocumentRecord(ref){const key=documentBucket(ref);if(!documentBucketCache.has(key))documentBucketCache.set(key,readDocumentJson('data/product-documents/'+key+'.json').catch(error=>{documentBucketCache.delete(key);throw error;}));return documentBucketCache.get(key).then(data=>data[ref]);}
const documentStatusLabels={pilot_documented:'Ficha piloto documentada',chemical_draft:'Extração automática de Químicos · por validar',source_partial:'Ficha documental parcial',no_source:'Sem página técnica associada'};
function documentSourceButton(source){return '<button type="button" class="document-source" onclick="openCatalogPage(\''+source.slug+'\','+source.page+')">'+esc(source.catalogTitle)+' · pág. '+source.page+'</button>';}
function documentDraftHtml(draft,registry){
 const names={characteristics:'Características',technical:'Dados técnicos',applications:'Aplicações',instructions:'Modo de utilização',limitations:'Limitações',precautions:'Precauções',notes:'Notas'};
 return '<div class="document-draft"><strong>Extração automática por validar</strong><p>O texto abaixo foi separado por títulos numa página com uma referência reconhecida. Ainda não foi validada a atribuição de cada frase ao produto. Não é uma ficha técnica aprovada.</p>'+draft.sections.map(s=>'<details><summary>'+esc(names[s.kind]||s.heading)+'</summary><pre>'+esc(s.text)+'</pre>'+documentSourceButton(registry[draft.sourceId])+'</details>').join('')+'</div>';
}
const documentOriginalDetail=detail;
detail=function(ref){
 if(!PRODUCTS.some(p=>p[0]===ref))return;
 documentOriginalDetail(ref);
 if(PRODUCT_TECH_SHEETS[ref])return;
 const dialog=document.querySelector('.dialog');if(!dialog)return;
 const panel=document.createElement('section');panel.className='global-document-sheet';panel.dataset.reference=ref;
 panel.innerHTML='<h3>Documentação técnica</h3><p>A carregar as fontes da referência '+esc(ref)+'…</p>';
 dialog.querySelector('h3').insertAdjacentElement('afterend',panel);
 Promise.all([productDocumentRecord(ref),documentRegistry()]).then(([record,registry])=>{
  if(!panel.isConnected)return;
  if(!record)throw Error('Registo documental em falta');
  panel.innerHTML='<h3>'+esc(documentStatusLabels[record.status])+'</h3>'+
   (record.status==='no_source'?'<p>Não foi identificada uma página com esta referência nos quatro catálogos completos disponíveis. Mantêm-se os dados comerciais; características, utilização, limitações e fotografia individual ficam por confirmar.</p>':'<p>As páginas abaixo incluem esta referência. Uma página pode conter vários produtos ou variantes: as características e fotografias da página não foram atribuídas automaticamente ao artigo.</p>')+
   '<div>'+record.sources.map(id=>documentSourceButton(registry[id])).join(' ')+'</div>'+
   (record.draft?documentDraftHtml(record.draft,registry):'')+
   '<p class="muted">Fotografia individual não validada neste lote. A imagem original da página, quando disponível, continua acessível. O preço e a embalagem mantêm a origem comercial existente.</p>';
 }).catch(()=>{if(panel.isConnected)panel.innerHTML='<h3>Documentação técnica</h3><p>Não foi possível carregar o registo. Fecha e volta a abrir a ficha para tentar novamente. Não foram inferidos dados técnicos.</p>';});
};
const documentStyle=document.createElement('style');documentStyle.textContent='.global-document-sheet{padding:16px;border:2px solid #e5a264;border-radius:12px;background:#fffdf8;margin:16px 0}.document-source{margin:4px 4px 4px 0;max-width:100%;font-size:13px}.document-draft{background:#fff0da;padding:14px;margin-top:15px;border-left:4px solid #d46a00}.document-draft summary{cursor:pointer;padding:10px 0;font-weight:650}.document-draft pre{font:15px/1.5 system-ui;white-space:pre-wrap;overflow-wrap:anywhere}';document.head.append(documentStyle);
async function openDocumentHash(){
 const product=location.hash.match(/^#ficha\/([A-Za-z0-9_-]+)$/);if(product&&PRODUCTS.some(p=>p[0]===product[1])){detail(product[1]);return;}
 const source=location.hash.match(/^#fonte\/([a-z0-9-]+)\/(\d+)$/);
 if(source){const registry=await documentRegistry(),id=source[1]+':'+Number(source[2]);if(registry[id])openCatalogPage(source[1],Number(source[2]));}
}
window.addEventListener('hashchange',openDocumentHash);openDocumentHash();

const documentReviewLink=document.createElement("a");documentReviewLink.className="action";documentReviewLink.href="revisao-fichas.html";documentReviewLink.textContent="Revisão das fichas";document.querySelector("nav").append(documentReviewLink);
